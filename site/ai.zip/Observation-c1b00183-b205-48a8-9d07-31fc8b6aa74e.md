# c1b00183-b205-48a8-9d07-31fc8b6aa74e - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **c1b00183-b205-48a8-9d07-31fc8b6aa74e**

## Example Observation: c1b00183-b205-48a8-9d07-31fc8b6aa74e



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "c1b00183-b205-48a8-9d07-31fc8b6aa74e",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2023-05-03T11:15:00+01:00",
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Observation_Laboratory_Study|1.0.0-update"]
  },
  "extension" : [{
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_External_Service",
    "valueBoolean" : true
  },
  {
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Association_Service",
    "valueBoolean" : true
  },
  {
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Accredited_Service",
    "valueBoolean" : true
  },
  {
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_zlog",
    "valueDecimal" : 2
  },
  {
    "extension" : [{
      "url" : "value",
      "valueRatio" : {
        "numerator" : {
          "value" : 6.5,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "denominator" : {
          "value" : 8.5,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        }
      }
    },
    {
      "url" : "referenceRange",
      "valueRange" : {
        "low" : {
          "value" : 3,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "high" : {
          "value" : 10,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        }
      }
    },
    {
      "url" : "zlog",
      "valueDecimal" : 2
    }],
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Alternative_Result"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "OBI",
        "display" : "Observation Instance Identifier"
      }]
    },
    "system" : "http://www.acmedasdd.com/identifiers/patient",
    "value" : "123456"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "UDI",
        "display" : "Universal Device Identifier"
      }]
    },
    "system" : "http://www.acmedasdd.com/identifiers/patient",
    "value" : "123456"
  }],
  "status" : "final",
  "category" : [{
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "laboratory"
    }],
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "version" : "2.0.0",
      "code" : "laboratory",
      "display" : "Laboratory"
    }],
    "text" : "test"
  },
  {
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "studyType"
    }],
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "code" : "18717-9",
      "display" : "Blood bank studies (set)"
    }],
    "text" : "test"
  },
  {
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "testProfile"
    }],
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_MIO_LAB_Test_Profil_Laboruntersuchungsgruppe",
      "version" : "1.0.0-update",
      "code" : "haemato",
      "display" : "Hämatologie"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "code" : "98981-4",
      "display" : "Urate [Mass/volume] in Blood"
    }],
    "text" : "test"
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d",
    "identifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
          "code" : "KVZ10",
          "display" : "Krankenversichertennummer"
        }]
      },
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "K123456789"
    }
  },
  "effectiveDateTime" : "2021-11-15T11:30:00+01:00",
  "issued" : "2021-11-15T11:30:00+01:00",
  "performer" : [{
    "reference" : "PractitionerRole/a424d6c6-de52-443e-a9b2-5240d3b9401a"
  }],
  "valueRatio" : {
    "numerator" : {
      "value" : 6.5,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "denominator" : {
      "value" : 8.5,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    }
  },
  "interpretation" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
      "version" : "4.0.0",
      "code" : "CAR",
      "display" : "Carrier"
    },
    {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "371152001",
      "display" : "Assisted (qualifier value)"
    }],
    "text" : "test"
  }],
  "note" : [{
    "text" : "test"
  }],
  "method" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "4241000179101",
      "display" : "Laboratory report (record artifact)"
    }],
    "text" : "Blutgruppe"
  },
  "specimen" : {
    "reference" : "Specimen/4f47fe9c-d92e-46f4-ad6d-85740aaa467b"
  },
  "device" : {
    "reference" : "Device/18a30aa6-3b2d-4738-9ca9-125a452d14e0"
  },
  "referenceRange" : [{
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Source_Reference_Range",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/11000274103/version/20251115",
          "code" : "260394003",
          "display" : "Normal limits (qualifier value)"
        }],
        "text" : "note"
      }
    },
    {
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_No_Linear_Reference_Range",
      "valueBoolean" : true
    }],
    "low" : {
      "value" : 3,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "high" : {
      "value" : 10,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
        "version" : "1.0.1",
        "code" : "type",
        "display" : "Type"
      }],
      "text" : "test"
    },
    "appliesTo" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/sex-parameter-for-clinical-use",
        "version" : "2.0.0",
        "code" : "female-typical",
        "display" : "Apply female-typical setting or reference range"
      }],
      "text" : "Test"
    }],
    "text" : "test"
  }],
  "derivedFrom" : [{
    "reference" : "Observation/035761c3-8934-499f-bf34-3963979afb56"
  }]
}

```
