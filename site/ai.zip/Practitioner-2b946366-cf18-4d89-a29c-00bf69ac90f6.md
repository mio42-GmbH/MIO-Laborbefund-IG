# 2b946366-cf18-4d89-a29c-00bf69ac90f6 - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **2b946366-cf18-4d89-a29c-00bf69ac90f6**

## Example Practitioner: 2b946366-cf18-4d89-a29c-00bf69ac90f6



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "2b946366-cf18-4d89-a29c-00bf69ac90f6",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2023-05-03T11:15:00+01:00",
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Practitioner|1.0.0-update"]
  },
  "extension" : [{
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_Base_Additional_Comment",
    "valueString" : "test"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "LANR",
        "display" : "Lifelong physician number"
      }]
    },
    "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_ANR",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "DN",
        "display" : "Doctor number"
      }]
    },
    "system" : "http://fhir.de/sid/bundesaerztekammer/efn",
    "value" : "123456789123456"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
        "code" : "ZANR",
        "display" : "Zahnarztnummer"
      }]
    },
    "system" : "http://fhir.de/sid/kzbv/zahnarztnummer",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "PRN",
        "display" : "Provider number"
      }]
    },
    "system" : "https://gematik.de/fhir/sid/telematik-id",
    "value" : "123456789"
  },
  {
    "system" : "http://testsystem.de",
    "value" : "testValue"
  }],
  "name" : [{
    "use" : "official",
    "text" : "Dr. Hans Glücklich",
    "family" : "Hans",
    "_family" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
        "valueString" : "Glücklich"
      },
      {
        "url" : "http://fhir.de/StructureDefinition/humanname-namenszusatz",
        "valueString" : "Prinz"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-prefix",
        "valueString" : "von"
      }]
    },
    "given" : ["Hans"],
    "prefix" : ["Dr"],
    "_prefix" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
        "valueCode" : "AC"
      }]
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "12123455"
  }],
  "address" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-precinct",
      "valueString" : "Schöneberg"
    }],
    "type" : "both",
    "line" : ["Schöneberg"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Mittestr"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "43"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
        "valueString" : "Nebenhaus"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "12015",
    "country" : "D"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-precinct",
      "valueString" : "Schöneberg"
    }],
    "type" : "postal",
    "line" : ["Schöneberg"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
        "valueString" : "Mittestraße 3"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "12015",
    "country" : "D"
  }],
  "gender" : "other",
  "_gender" : {
    "extension" : [{
      "url" : "http://fhir.de/StructureDefinition/gender-amtlich-de",
      "valueCoding" : {
        "system" : "http://fhir.de/CodeSystem/gender-amtlich-de",
        "code" : "X",
        "display" : "unbestimmt"
      }
    }]
  },
  "qualification" : [{
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/11000274103/version/20250515",
        "code" : "26369006",
        "display" : "Public health nurse"
      }]
    }
  }]
}

```
