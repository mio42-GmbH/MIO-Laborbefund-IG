# 4f47fe9c-d92e-46f4-ad6d-85740aaa467b - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **4f47fe9c-d92e-46f4-ad6d-85740aaa467b**

## Example Specimen: 4f47fe9c-d92e-46f4-ad6d-85740aaa467b



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "4f47fe9c-d92e-46f4-ad6d-85740aaa467b",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2023-05-03T11:15:00+01:00",
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Specimen|1.0.0-update"]
  },
  "extension" : [{
    "url" : "http://hl7.eu/fhir/laboratory/StructureDefinition/specimen-focus",
    "valueReference" : {
      "reference" : "Device/c46e7bfb-1ee3-4c6b-9ce2-204939133cc5"
    }
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "version" : "5.0.0",
        "code" : "SID",
        "display" : "Specimen ID"
      }]
    },
    "system" : "http://testsystem.de",
    "value" : "Test Specimen identifier"
  }],
  "status" : "available",
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "119376003",
      "display" : "Tissue specimen (specimen)"
    }],
    "text" : "test"
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d",
    "identifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
          "code" : "KVZ10",
          "display" : "Krankenversichertennummer"
        }]
      },
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "K123456789"
    }
  },
  "receivedTime" : "2021-11-15T16:55:00+01:00",
  "parent" : [{
    "reference" : "Specimen/eb7fbea2-95bd-4618-b38d-ce69cde79726"
  }],
  "collection" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/bodySite",
      "valueReference" : {
        "reference" : "BodyStructure/6894b106-8a91-4cfb-9826-443aed21c98b"
      }
    }],
    "collector" : {
      "reference" : "PractitionerRole/a424d6c6-de52-443e-a9b2-5240d3b9401a"
    },
    "collectedDateTime" : "2023-05-03",
    "duration" : {
      "value" : 20,
      "comparator" : ">",
      "unit" : "ms",
      "system" : "http://unitsofmeasure.org",
      "code" : "ms"
    },
    "method" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/11000274103/version/20251115",
        "code" : "4241000179101",
        "display" : "Laboratory report (record artifact)"
      }],
      "text" : "test"
    },
    "fastingStatusDuration" : {
      "value" : 20,
      "comparator" : ">",
      "unit" : "ms",
      "system" : "http://unitsofmeasure.org",
      "code" : "ms"
    }
  },
  "processing" : [{
    "description" : "test",
    "procedure" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0373",
        "version" : "3.0.0",
        "code" : "ACID",
        "display" : "Acidification"
      }],
      "text" : "test"
    },
    "additive" : [{
      "reference" : "Substance/a4b533d4-0a3c-4701-b411-fd9666bf3d03"
    }],
    "timeDateTime" : "2023-05-03"
  }],
  "container" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Specimen.container.device",
      "valueReference" : {
        "reference" : "Device/05146497-2ca3-488e-96cb-c27c77ab6a3c"
      }
    }],
    "specimenQuantity" : {
      "value" : 20,
      "unit" : "ms",
      "system" : "http://unitsofmeasure.org",
      "code" : "ms"
    }
  }],
  "condition" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0493",
      "version" : "3.0.0",
      "code" : "AUT",
      "display" : "Autolyzed"
    }],
    "text" : "test"
  }],
  "note" : [{
    "text" : "test"
  }]
}

```
