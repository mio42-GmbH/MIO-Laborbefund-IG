# 51b6129a-b68c-485d-a37b-9593fee4354f - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **51b6129a-b68c-485d-a37b-9593fee4354f**

## Example Observation: 51b6129a-b68c-485d-a37b-9593fee4354f



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "51b6129a-b68c-485d-a37b-9593fee4354f",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2023-05-03T11:15:00+01:00",
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Observation_Laboratory_Study_Group|1.0.0-update"]
  },
  "status" : "final",
  "category" : [{
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "laboratory"
    }],
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "version" : "2.0.0",
      "code" : "laboratory",
      "display" : "Laboratory"
    }],
    "text" : "test"
  },
  {
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "studyType"
    }],
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "code" : "18717-9",
      "display" : "Blood bank studies (set)"
    }],
    "text" : "test"
  },
  {
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Diskriminator",
      "valueString" : "testProfile"
    }],
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_MIO_LAB_Test_Profil_Laboruntersuchungsgruppe",
      "version" : "1.0.0-update",
      "code" : "haemato",
      "display" : "Hämatologie"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_MIO_LAB_mio42",
      "version" : "1.0.0-update",
      "code" : "laboruntersuchungsgruppe",
      "display" : "Laboruntersuchungsgruppe"
    }]
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d",
    "identifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
          "code" : "KVZ10",
          "display" : "Krankenversichertennummer"
        }]
      },
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "K123456789"
    }
  },
  "_effectiveDateTime" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
      "valueCode" : "not-permitted"
    }]
  },
  "performer" : [{
    "reference" : "PractitionerRole/a424d6c6-de52-443e-a9b2-5240d3b9401a"
  }],
  "interpretation" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
      "version" : "4.0.0",
      "code" : "D",
      "display" : "Significant change down"
    },
    {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "281300000",
      "display" : "Below reference range (qualifier value)"
    }],
    "text" : "test"
  }],
  "note" : [{
    "text" : "test"
  }],
  "hasMember" : [{
    "extension" : [{
      "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Sorting_Number",
      "valuePositiveInt" : 1
    }],
    "reference" : "Observation/035761c3-8934-499f-bf34-3963979afb56"
  }]
}

```
