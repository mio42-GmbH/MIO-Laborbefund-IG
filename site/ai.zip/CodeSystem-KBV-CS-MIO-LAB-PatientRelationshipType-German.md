# PatientRelationshipType German - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **PatientRelationshipType German**

## CodeSystem: PatientRelationshipType German 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.kbv.de/CodeSystem/KBV_CS_MIO_LAB_PatientRelationshipType_German | *Version*:1.0.0-update |
| Draft as of 2026-06-17 | *Computable Name*:KBV_CS_MIO_LAB_PatientRelationshipType_German |
| **Copyright/Legal**: Im folgenden Profil können Codes aus den Codesystemen Snomed, Loinc oder Ucum enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. This material contains content from LOINC (http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://loinc.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at ​http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED “AS IS.” ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. | |

 
Dieses Codesystem enthält die Codes für deutsche Bezeichner für PatientRelationshipType German. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "KBV-CS-MIO-LAB-PatientRelationshipType-German",
  "url" : "https://fhir.kbv.de/CodeSystem/KBV_CS_MIO_LAB_PatientRelationshipType_German",
  "version" : "1.0.0-update",
  "name" : "KBV_CS_MIO_LAB_PatientRelationshipType_German",
  "title" : "PatientRelationshipType German",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-17T15:03:17+02:00",
  "publisher" : "mio42 GmbH",
  "contact" : [{
    "name" : "mio42 GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://mio.kbv.de"
    },
    {
      "system" : "email",
      "value" : "hello@mio42.de"
    }]
  }],
  "description" : "Dieses Codesystem enthält die Codes für deutsche Bezeichner für PatientRelationshipType German.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "Im folgenden Profil können Codes aus den Codesystemen Snomed, Loinc oder Ucum enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. This material contains content from LOINC (http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://loinc.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at ​http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED \"AS IS.\" ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.",
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "Adoptivvater",
    "display" : "Adoptivvater"
  },
  {
    "code" : "Adoptivmutter",
    "display" : "Adoptivmutter"
  },
  {
    "code" : "Adoptivelternteil",
    "display" : "Adoptivelternteil"
  },
  {
    "code" : "Tante",
    "display" : "Tante"
  },
  {
    "code" : "Schwager",
    "display" : "Schwager"
  },
  {
    "code" : "Bruder",
    "display" : "Bruder"
  },
  {
    "code" : "Kind",
    "display" : "Kind"
  },
  {
    "code" : "Adoptivkind",
    "display" : "Adoptivkind"
  },
  {
    "code" : "Pflegekind",
    "display" : "Pflegekind"
  },
  {
    "code" : "Schwiegerkind",
    "display" : "Schwiegerkind"
  },
  {
    "code" : "Cousine",
    "display" : "Cousin(e)"
  },
  {
    "code" : "AnsprechpartnerIninNotfaellen",
    "display" : "AnsprechpartnerIn in Notfällen"
  },
  {
    "code" : "Adoptivtochter",
    "display" : "Adoptivtochter"
  },
  {
    "code" : "Tochter",
    "display" : "Tochter"
  },
  {
    "code" : "Pflegetochter",
    "display" : "Pflegetochter"
  },
  {
    "code" : "Schwiegertochter",
    "display" : "Schwiegertochter"
  },
  {
    "code" : "LeiblicheTochter",
    "display" : "Leibliche Tochter"
  },
  {
    "code" : "Lebenspartnerin",
    "display" : "Lebenspartner/-in"
  },
  {
    "code" : "ErweitertesFamilienmitglied",
    "display" : "Erweitertes Familienmitglied"
  },
  {
    "code" : "ArbeitgeberIn",
    "display" : "ArbeitgeberIn"
  },
  {
    "code" : "Familienmitglied",
    "display" : "Familienmitglied"
  },
  {
    "code" : "EhemaligerEhepartnerIn",
    "display" : "Ehemalige(r) EhepartnerIn"
  },
  {
    "code" : "NichtverwandterFreundIn",
    "display" : "Nicht verwandte(r) FreundIn"
  },
  {
    "code" : "Ziehvater",
    "display" : "Ziehvater"
  },
  {
    "code" : "Schwiegervater",
    "display" : "Schwiegervater"
  },
  {
    "code" : "Vater",
    "display" : "Vater"
  },
  {
    "code" : "zweieiigerZwillingsbruder",
    "display" : "zweieiiger Zwillingsbruder"
  },
  {
    "code" : "ZweieiigeZwillingsschwester",
    "display" : "Zweieiige Zwillingsschwester"
  },
  {
    "code" : "ZweieiigerZwilling",
    "display" : "Zweieiiger Zwilling"
  },
  {
    "code" : "Bundesbehoerde",
    "display" : "Bundesbehörde"
  },
  {
    "code" : "werdendeMutter",
    "display" : "werdende Mutter"
  },
  {
    "code" : "Urgrossvater",
    "display" : "Urgroßvater"
  },
  {
    "code" : "Urgrossmutter",
    "display" : "Urgroßmutter"
  },
  {
    "code" : "Urgrosseltern",
    "display" : "Urgroßeltern"
  },
  {
    "code" : "Grossvater",
    "display" : "Großvater"
  },
  {
    "code" : "Grossmutter",
    "display" : "Großmutter"
  },
  {
    "code" : "Enkelkind",
    "display" : "Enkelkind"
  },
  {
    "code" : "Enkeltochter",
    "display" : "Enkeltochter"
  },
  {
    "code" : "Enkelsohn",
    "display" : "Enkelsohn"
  },
  {
    "code" : "Grosseltern",
    "display" : "Großeltern"
  },
  {
    "code" : "Halbbruder",
    "display" : "Halbbruder"
  },
  {
    "code" : "Halbgeschwister",
    "display" : "Halbgeschwister"
  },
  {
    "code" : "Halbschwester",
    "display" : "Halbschwester"
  },
  {
    "code" : "Ehemann",
    "display" : "Ehemann"
  },
  {
    "code" : "Schwiegerperson",
    "display" : "Schwiegerperson"
  },
  {
    "code" : "EineiigerZwillingsbruder",
    "display" : "Eineiiger Zwillingsbruder"
  },
  {
    "code" : "EineiigeZwillingsschwester",
    "display" : "Eineiige Zwillingsschwester"
  },
  {
    "code" : "EineiigerZwilling",
    "display" : "Eineiiger Zwilling"
  },
  {
    "code" : "Versicherung",
    "display" : "Versicherung"
  },
  {
    "code" : "Tantemuetterlicherseits",
    "display" : "Tante mütterlicherseits"
  },
  {
    "code" : "Cousinmuetterlicherseits",
    "display" : "Cousin mütterlicherseits"
  },
  {
    "code" : "Urgrossvatermuetterlicherseits",
    "display" : "Urgroßvater mütterlicherseits"
  },
  {
    "code" : "Urgrossmuttermuetterlicherseits",
    "display" : "Urgroßmutter mütterlicherseits"
  },
  {
    "code" : "Urgrosselternmuetterlicherseits",
    "display" : "Urgroßeltern mütterlicherseits"
  },
  {
    "code" : "Grossvatermuetterlicherseits",
    "display" : "Großvater mütterlicherseits"
  },
  {
    "code" : "Grossmuttermuetterlicherseits",
    "display" : "Großmutter mütterlicherseits"
  },
  {
    "code" : "Grosselternmuetterlicherseits",
    "display" : "Großeltern mütterlicherseits"
  },
  {
    "code" : "Pflegemutter",
    "display" : "Pflegemutter"
  },
  {
    "code" : "Schwiegermutter",
    "display" : "Schwiegermutter"
  },
  {
    "code" : "Mutter",
    "display" : "Mutter"
  },
  {
    "code" : "Onkelmuetterlicherseits",
    "display" : "Onkel mütterlicherseits"
  },
  {
    "code" : "NachbarIn",
    "display" : "NachbarIn"
  },
  {
    "code" : "LeiblicherBruder",
    "display" : "Leiblicher Bruder"
  },
  {
    "code" : "LeiblichesKind",
    "display" : "Leibliches Kind"
  },
  {
    "code" : "Neffe",
    "display" : "Neffe"
  },
  {
    "code" : "LeiblicherVaterdesFoetus",
    "display" : "Leiblicher Vater des Fötus"
  },
  {
    "code" : "LeiblicherVater",
    "display" : "Leiblicher Vater"
  },
  {
    "code" : "Nichte",
    "display" : "Nichte"
  },
  {
    "code" : "NichteNeffe",
    "display" : "Nichte/Neffe"
  },
  {
    "code" : "LeiblicheMutterdesFoetus",
    "display" : "Leibliche Mutter des Fötus"
  },
  {
    "code" : "LeiblicheMutter",
    "display" : "Leibliche Mutter"
  },
  {
    "code" : "LeiblicherElternteil",
    "display" : "Leiblicher Elternteil"
  },
  {
    "code" : "LeiblichesGeschwisterkind",
    "display" : "Leibliches Geschwisterkind"
  },
  {
    "code" : "LeiblicheSchwester",
    "display" : "Leibliche Schwester"
  },
  {
    "code" : "Kontaktperson",
    "display" : "Kontaktperson"
  },
  {
    "code" : "Selbst",
    "display" : "Selbst"
  },
  {
    "code" : "Andere",
    "display" : "Andere"
  },
  {
    "code" : "Tantevaeterlicherseits",
    "display" : "Tante väterlicherseits"
  },
  {
    "code" : "Cousinvaeterlicherseits",
    "display" : "Cousin väterlicherseits"
  },
  {
    "code" : "Urgrossvatervaeterlicherseits",
    "display" : "Urgroßvater väterlicherseits"
  },
  {
    "code" : "Urgrossmuttervaeterlicherseits",
    "display" : "Urgroßmutter väterlicherseits"
  },
  {
    "code" : "Urgrosselternvaeterlicherseits",
    "display" : "Urgroßeltern väterlicherseits"
  },
  {
    "code" : "Grossvatervaeterlicherseits",
    "display" : "Großvater väterlicherseits"
  },
  {
    "code" : "Grossmuttervaeterlicherseits",
    "display" : "Großmutter väterlicherseits"
  },
  {
    "code" : "Grosselternvaeterlicherseits",
    "display" : "Großeltern väterlicherseits"
  },
  {
    "code" : "Pflegeeltern",
    "display" : "Pflegeeltern"
  },
  {
    "code" : "Schwiegereltern",
    "display" : "Schwiegereltern"
  },
  {
    "code" : "Elternteil",
    "display" : "Elternteil"
  },
  {
    "code" : "Onkelvaeterlicherseits",
    "display" : "Onkel väterlicherseits"
  },
  {
    "code" : "MitbewohnerIn",
    "display" : "MitbewohnerIn"
  },
  {
    "code" : "Schwiegergeschwister",
    "display" : "Schwiegergeschwister"
  },
  {
    "code" : "Geschwisterteil",
    "display" : "Geschwisterteil"
  },
  {
    "code" : "Lebensgefaehrtein",
    "display" : "Lebensgefährte/-in"
  },
  {
    "code" : "Schwaegerin",
    "display" : "Schwägerin"
  },
  {
    "code" : "Schwester",
    "display" : "Schwester"
  },
  {
    "code" : "Adoptivsohn",
    "display" : "Adoptivsohn"
  },
  {
    "code" : "Sohn",
    "display" : "Sohn"
  },
  {
    "code" : "Pflegesohn",
    "display" : "Pflegesohn"
  },
  {
    "code" : "Schwiegersohn",
    "display" : "Schwiegersohn"
  },
  {
    "code" : "LeiblicherSohn",
    "display" : "Leiblicher Sohn"
  },
  {
    "code" : "EhepartnerIn",
    "display" : "EhepartnerIn"
  },
  {
    "code" : "Stiefbruder",
    "display" : "Stiefbruder"
  },
  {
    "code" : "Stiefkind",
    "display" : "Stiefkind"
  },
  {
    "code" : "Stieftochter",
    "display" : "Stieftochter"
  },
  {
    "code" : "Stiefvater",
    "display" : "Stiefvater"
  },
  {
    "code" : "Stiefmutter",
    "display" : "Stiefmutter"
  },
  {
    "code" : "Stiefelternteil",
    "display" : "Stiefelternteil"
  },
  {
    "code" : "Stiefgeschwister",
    "display" : "Stiefgeschwister"
  },
  {
    "code" : "Stiefschwester",
    "display" : "Stiefschwester"
  },
  {
    "code" : "Stiefsohn",
    "display" : "Stiefsohn"
  },
  {
    "code" : "Landesbehoerde",
    "display" : "Landesbehörde"
  },
  {
    "code" : "Zwillingsbruder",
    "display" : "Zwillingsbruder"
  },
  {
    "code" : "Zwillingsschwester",
    "display" : "Zwillingsschwester"
  },
  {
    "code" : "Zwilling",
    "display" : "Zwilling"
  },
  {
    "code" : "Onkel",
    "display" : "Onkel"
  },
  {
    "code" : "Unbekannt",
    "display" : "Unbekannt"
  },
  {
    "code" : "Ehefrau",
    "display" : "Ehefrau"
  }]
}

```
