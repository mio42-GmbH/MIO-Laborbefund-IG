# Projektübersicht - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* **Projektübersicht**

## Projektübersicht

| | |
| :--- | :--- |
| *Official URL*:https://fhir.kbv.de/ImplementationGuide/kbv.mio.laborbefund | *Version*:1.0.0-update |
| Draft as of 2026-06-30 | *Computable Name*:KBVMIOLaborbefund |

**🛈 Disclaimer**

Dieser Implementation Guide (IG) entstand teilweise parallel zum [Fachkonzept “Digital gestützter Laborprozess - Stufe 1”](https://fachportal.gematik.de/fileadmin/user_upload/gemKPT_FK_epafueralle_dgLP_V1.0.0.pdf)der gematik. Die mio42 GmbH war in den Prozess der Fachkonzepterstellung involviert. Die Ausführungen im IG zum Scope und zur Ausgestaltung des MIO Laborbefund sollten daher inhaltsgleich zum dgLP-Fachkonzept sein. Soweit dennoch Inkonsistenzen festzustellen sind, führt das Fachkonzept.

### Laborbefunde heute

Die Ergebnisse von patientenbezogenen medizinischen Laboruntersuchungen werden in Form eines Laborbefundes zusammengestellt. Das ist ein labormedizinisch ärztlich validierter Befundbericht, der neben administrativen Daten (z. B. Einsender:in, Patient:in, leistungserbringendes Laboratorium, Befunder:in) die Ergebnisse der gemessenen Laborparameter und die Bewertung dieser im medizinischen Kontext enthält.

Labordiagnostik wird fachübergreifend für nahezu alle medizinischen Disziplinen angewendet, sowohl im ambulanten als auch im stationären Bereich. Laborergebnisse spielen eine wichtige Rolle bei der Diagnose, der Behandlung und der Nachsorge von Patient:innen.

Die Laborbefundkommunikation in Deutschland basiert nach heutigem Stand noch zu einem Teil auf Papierformularen und ausgedruckten Befunden. Die Digitalisierung der Laborbefundkommunikation ist unterschiedlich weit ausgereift. Teilweise existieren analoge und digitale Prozesse in Kombination, z. B. erfolgt die Anforderung aus einer Praxis per Papierformular, das Ergebnis wird vom Labor jedoch digital übermittelt. Wenn eine Aushändigung des Laborbefundes direkt an Patient:innen erfolgt, dann durch die behandelnde Person oft in Papierform. Zur Digitalisierung von Laborbefunden gibt es national und international zahlreiche Projekte und einige Standardisierungsansätze (z. B. LDT 2 und LDT 3 im niedergelassenen Sektor, HL7 v2 und zukünftig ISiK im KH-Sektor). Aufgrund eines fehlenden, sektorenübergreifend verbindlichen semantischen und syntaktischen Standards ist der digitale Austausch von Labordaten zwischen einzelnen Leistungserbringenden und deren nutzbringende Weiterverarbeitung im empfangenden Primärsystem aktuell nicht der Regelfall. Er funktioniert meist nur individuell zwischen beauftragender/m Praxis/KH und konkretem Labor. Ein Austausch und eine Weiternutzung für weitere Beteiligte über die ePA erfolgt aktuell über PDF/A.

### MIO-Umsetzung

Die Digitalisierung von Laborbefunden in strukturierter, standardisiert maschinenlesbarer Form ist die Grundlage für eine präzise und nahtlose Kommunikation der Laborergebnisse zwischen behandelnden Personen und ihren PatientInnen. Laborbefunde zukünftig ohne Mehraufwand generieren, verarbeiten und kommunizieren zu können, erfordert langfristig ein einheitliches syntaktisches Format (**HL7® FHIR®**). Für die digitale Zustellung des Laborbefundes an jegliche Praxis oder Klinik wäre dann keine Format-Konvertierung mehr notwendig und das MIO könnte von sämtlichen Software-Systemen unmittelbar gelesen und angezeigt werden.

Perspektivisch erlaubt ein automatisierter Versand und Empfang von strukturierten digitalen Laborbefunden zwischen leistungserbringenden Laboratorien und empfangenden Systemen, den Verarbeitungsaufwand zu minimieren und die Auswertungsprozesse zu optimieren. Das übergeordnete Ziel ist es, die Qualität der medizinischen Diagnostik sicherzustellen, kritische Laborergebnisse rechtzeitig zu identifizieren und Patient:innen die bestmögliche Versorgung zukommen zu lassen.

Die Umsetzung des MIO Laborbefund in der ersten Ausbaustufe beginnt mit den essenziellen fachübergreifenden Laboruntersuchungen, inklusive Antigen- und Antikörperbestimmung, sodass mit diesem Ansatz die Voraussetzung für eine breite Verwendbarkeit geschaffen wird. Spezialbereiche, wie beispielsweise Mikrobiologische Kulturen, Zytologie oder Humangenetik werden nachgelagert schrittweise umgesetzt.

### Wo stehen wir?

Die Spezifikationserstellung für das MIO Laborbefund wurde im Sommer 2024 erstmalig abgeschlossen und hat im Sommer 2025 ein Update erfahren. Die Datenstruktur hierfür wurde jeweils mit den maßgeblich betroffenen Fachgesellschaften und Spitzenorganisationen im Rahmen von fachlichen Reviews gemeinsam spezifiziert.

Im Herbst 2025 fand das Xt-EHR-Konsultationsverfahren für den ab März 2031 im Europäischen Datenraum (EHDS) einheitlich zu verwendenden Laboratory Report statt (s. [aktuelle Fassung](https://build.fhir.org/ig/hl7-eu/laboratory/)). Das MIO Laborbefund hat zur Sicherstellung der notwendigen Kompatibilität entsprechende Anpassungen erfahren. Der nun seitens der mio42 GmbH erreichte Zwischenstand wird hiermit veröffentlicht, um den Primärsystemanbietern und Anwendenden frühzeitige Orientierung und abschließende Feedback-Möglichkeit zu geben. Damit sollen sowohl die Spezifikation als auch die Begleittexte und Unterstützungspakete ihren letzten Feinschliff bekommen. Weitere Informationen zur Beteiligung an dieser Feedbackrunde erhalten Sie auf der [Feedback-Seite](./Feedback.md).

### Nächste Schritte

Seit Mai 2026 befinden wir uns in der Abstimmung mit der gematik zur Integration des MIO Laborbefund in die ePA-Aktensysteme. Diese Arbeiten münden dann in einem gemeinsamen Implementation Guide mit der gematik zum digital gestützten Laborprozess (dgLP). Dieser soll entsprechend der [OneRoadmap der gematik](https://fachportal.gematik.de/schnelleinstieg/roadmap) zum Jahresende 2026 veröffentlicht werden.

Stand: Juni 2026

### Kontakt & Support

Allgemeine Fragen und Anmerkungen zum MIO Laborbefund können Sie via E-Mail an [laborbefund@mio42.de](mailto:laborbefund@mio42.de) mit dem Betreff “Zwischenveröffentlichung MIO Laborbefund” schicken.

### Abhängigkeiten













*There are no Global profiles defined*

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (kbv.mio.laborbefund.r4)](package.r4.tgz) and [R4B (kbv.mio.laborbefund.r4b)](package.r4b.tgz) are available.

