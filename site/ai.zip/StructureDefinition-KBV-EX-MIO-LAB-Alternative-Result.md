# KBV_EX_MIO_LAB_Alternative_Result - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **KBV_EX_MIO_LAB_Alternative_Result**

## Extension: KBV_EX_MIO_LAB_Alternative_Result 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Alternative_Result | *Version*:1.0.0-update |
| Draft as of 2026-06-11 | *Computable Name*:KBV_EX_MIO_LAB_Alternative_Result |
| **Copyright/Legal**: Im folgenden Profil können Codes aus den Code-Systemen SNOMED CT®, LOINC, Ucum, ATC, ICD-10-GM, ICD-10-WHO, OPS, Alpha-ID/Alpha-ID-SE und ICF enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED CT® Clinical Terms® (SNOMED CT® CT®) which is used by permission of SNOMED CT® International. All rights reserved. SNOMED CT® CT®, was originally created by The College of American Pathologists. SNOMED CT® and SNOMED CT® CT are registered trademarks of SNOMED CT® International. Implementers of these artefacts must have the appropriate SNOMED CT® CT Affiliate license. This material contains content from LOINC (http://LOINC.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://LOINC.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED ‘AS IS.’ ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Dieses Material enthält Inhalte aus ATC. Die Erstellung erfolgte unter Verwendung der Datenträger der amtlichen Fassung der ATC-Klassifikation mit DDD des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICD-10-GM, ICD-10-WHO, OPS Alpha-ID ans Alpha-ID-SE. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICF. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Deutschen Instituts für Medizinische Dokumentation und Information (DIMDI). ICF-Kodes, -Begriffe und -Texte © Weltgesundheitsorganisation, übersetzt und herausgegeben durch das Deutsche Institut für Medizinische Dokumentation und Information von der International classification of functioning, disability and health - ICF, herausgegeben durch die Weltgesundheitsorganisation. | |

Diese Extension bildet das Resultat einer Laboruntersuchung mit einer Alternativeinheit ab.

**Context of Use**

This extension may be used on the following element(s):

* Element ID Observation

**Usage info**

**Usages:**

* Use this Extension: [KBV_PR_MIO_LAB_Observation_Laboratory_Study](StructureDefinition-KBV-PR-MIO-LAB-Observation-Laboratory-Study.md)
* Examples for this Extension: [Observation/035761c3-8934-499f-bf34-3963979afb56](Observation-035761c3-8934-499f-bf34-3963979afb56.md), [Observation/6a2a44c6-92f8-40cf-a0bc-673404f7ac9b](Observation-6a2a44c6-92f8-40cf-a0bc-673404f7ac9b.md) and [Observation/c1b00183-b205-48a8-9d07-31fc8b6aa74e](Observation-c1b00183-b205-48a8-9d07-31fc8b6aa74e.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/kbv.mio.laborbefund|current/StructureDefinition/StructureDefinition-KBV-EX-MIO-LAB-Alternative-Result.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-KBV-EX-MIO-LAB-Alternative-Result.csv), [Excel](StructureDefinition-KBV-EX-MIO-LAB-Alternative-Result.xlsx), [Schematron](StructureDefinition-KBV-EX-MIO-LAB-Alternative-Result.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "KBV-EX-MIO-LAB-Alternative-Result",
  "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Alternative_Result",
  "version" : "1.0.0-update",
  "name" : "KBV_EX_MIO_LAB_Alternative_Result",
  "title" : "KBV_EX_MIO_LAB_Alternative_Result",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-11",
  "publisher" : "mio42 GmbH",
  "contact" : [{
    "name" : "mio42 GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://mio.kbv.de"
    },
    {
      "system" : "email",
      "value" : "hello@mio42.de"
    }]
  }],
  "description" : "Diese Extension bildet das Resultat einer Laboruntersuchung mit einer Alternativeinheit ab.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "Im folgenden Profil können Codes aus den Code-Systemen SNOMED CT®, LOINC, Ucum, ATC, ICD-10-GM, ICD-10-WHO, OPS, Alpha-ID/Alpha-ID-SE und ICF enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED CT® Clinical Terms® (SNOMED CT® CT®) which is used by permission of SNOMED CT® International. All rights reserved. SNOMED CT® CT®, was originally created by The College of American Pathologists. SNOMED CT® and SNOMED CT® CT are registered trademarks of SNOMED CT® International. Implementers of these artefacts must have the appropriate SNOMED CT® CT Affiliate license. This material contains content from LOINC (http://LOINC.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://LOINC.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED 'AS IS.' ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Dieses Material enthält Inhalte aus ATC. Die Erstellung erfolgte unter Verwendung der Datenträger der amtlichen Fassung der ATC-Klassifikation mit DDD des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICD-10-GM, ICD-10-WHO, OPS Alpha-ID ans Alpha-ID-SE. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICF. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Deutschen Instituts für Medizinische Dokumentation und Information (DIMDI). ICF-Kodes, -Begriffe und -Texte © Weltgesundheitsorganisation, übersetzt und herausgegeben durch das Deutsche Institut für Medizinische Dokumentation und Information von der International classification of functioning, disability and health - ICF, herausgegeben durch die Weltgesundheitsorganisation.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Observation"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "definition" : "Diese Extension bildet das Resultat einer Laboruntersuchung mit einer Alternativeinheit ab."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value",
      "path" : "Extension.extension",
      "sliceName" : "value",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:value.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:value.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "value"
    },
    {
      "id" : "Extension.extension:value.value[x]",
      "path" : "Extension.extension.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "type" : [{
        "code" : "Quantity"
      },
      {
        "code" : "Range"
      },
      {
        "code" : "Ratio"
      }]
    },
    {
      "id" : "Extension.extension:value.value[x]:valueQuantity",
      "path" : "Extension.extension.value[x]",
      "sliceName" : "valueQuantity",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }],
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:value.value[x]:valueQuantity.value",
      "path" : "Extension.extension.value[x].value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueQuantity.unit",
      "path" : "Extension.extension.value[x].unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueQuantity.system",
      "path" : "Extension.extension.value[x].system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueQuantity.code",
      "path" : "Extension.extension.value[x].code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange",
      "path" : "Extension.extension.value[x]",
      "sliceName" : "valueRange",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      }]
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.low",
      "path" : "Extension.extension.value[x].low",
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.low.value",
      "path" : "Extension.extension.value[x].low.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.low.unit",
      "path" : "Extension.extension.value[x].low.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.low.system",
      "path" : "Extension.extension.value[x].low.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.low.code",
      "path" : "Extension.extension.value[x].low.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.high",
      "path" : "Extension.extension.value[x].high",
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.high.value",
      "path" : "Extension.extension.value[x].high.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.high.unit",
      "path" : "Extension.extension.value[x].high.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.high.system",
      "path" : "Extension.extension.value[x].high.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRange.high.code",
      "path" : "Extension.extension.value[x].high.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio",
      "path" : "Extension.extension.value[x]",
      "sliceName" : "valueRatio",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Ratio"
      }]
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.numerator",
      "path" : "Extension.extension.value[x].numerator",
      "min" : 1,
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.numerator.value",
      "path" : "Extension.extension.value[x].numerator.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.numerator.unit",
      "path" : "Extension.extension.value[x].numerator.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.numerator.system",
      "path" : "Extension.extension.value[x].numerator.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.numerator.code",
      "path" : "Extension.extension.value[x].numerator.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.denominator",
      "path" : "Extension.extension.value[x].denominator",
      "min" : 1,
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.denominator.value",
      "path" : "Extension.extension.value[x].denominator.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.denominator.unit",
      "path" : "Extension.extension.value[x].denominator.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.denominator.system",
      "path" : "Extension.extension.value[x].denominator.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:value.value[x]:valueRatio.denominator.code",
      "path" : "Extension.extension.value[x].denominator.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange",
      "path" : "Extension.extension",
      "sliceName" : "referenceRange",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:referenceRange.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:referenceRange.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "referenceRange"
    },
    {
      "id" : "Extension.extension:referenceRange.value[x]",
      "path" : "Extension.extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "Range"
      }]
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].low",
      "path" : "Extension.extension.value[x].low",
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].low.value",
      "path" : "Extension.extension.value[x].low.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].low.unit",
      "path" : "Extension.extension.value[x].low.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].low.system",
      "path" : "Extension.extension.value[x].low.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].low.code",
      "path" : "Extension.extension.value[x].low.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].high",
      "path" : "Extension.extension.value[x].high",
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org"
      }
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].high.value",
      "path" : "Extension.extension.value[x].high.value",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].high.unit",
      "path" : "Extension.extension.value[x].high.unit",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].high.system",
      "path" : "Extension.extension.value[x].high.system",
      "min" : 1
    },
    {
      "id" : "Extension.extension:referenceRange.value[x].high.code",
      "path" : "Extension.extension.value[x].high.code",
      "min" : 1
    },
    {
      "id" : "Extension.extension:zlog",
      "path" : "Extension.extension",
      "sliceName" : "zlog",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:zlog.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:zlog.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "zlog"
    },
    {
      "id" : "Extension.extension:zlog.value[x]",
      "path" : "Extension.extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_MIO_LAB_Alternative_Result"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "max" : "0"
    }]
  }
}

```
