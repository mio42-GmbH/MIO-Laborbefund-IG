# Laboratory Report - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Laboratory Report**

## Example Composition: Laboratory Report



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "cdfb127b-df3c-493f-bc7e-e8be4a7bdc45",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2023-05-03T11:15:00+01:00",
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Composition|1.0.0-update"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Composition.version",
    "valueString" : "1"
  },
  {
    "url" : "http://hl7.eu/fhir/StructureDefinition/composition-basedOn-order-or-requisition",
    "valueReference" : {
      "reference" : "ServiceRequest/01a21c9c-2cd1-44e5-a999-f84d9ef70605"
    }
  },
  {
    "url" : "http://hl7.eu/fhir/extensions/StructureDefinition/composition-diagnosticReportReference",
    "valueReference" : {
      "reference" : "DiagnosticReport/3604d5a6-798e-4615-8a22-1d280638e2c0"
    }
  },
  {
    "url" : "http://hl7.eu/fhir/StructureDefinition/information-recipient",
    "valueReference" : {
      "reference" : "PractitionerRole/a424d6c6-de52-443e-a9b2-5240d3b9401a"
    }
  }],
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:123456"
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "4241000179101",
      "display" : "Laboratory report (record artifact)"
    }]
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d",
    "identifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
          "code" : "KVZ10",
          "display" : "Krankenversichertennummer"
        }]
      },
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "K123456789"
    }
  },
  "date" : "2022-03-23",
  "author" : [{
    "reference" : "Practitioner/2b946366-cf18-4d89-a29c-00bf69ac90f6"
  }],
  "title" : "Laboratory Report",
  "attester" : [{
    "mode" : "legal",
    "time" : "2023-05-03T11:15:00+01:00",
    "party" : {
      "reference" : "PractitionerRole/a424d6c6-de52-443e-a9b2-5240d3b9401a"
    }
  }],
  "section" : [{
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "version" : "2.82",
        "code" : "48767-8",
        "display" : "Annotation comment [Interpretation] Narrative"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">John Doe</div>"
    }
  }]
}

```
