# KBV_PR_MIO_LAB_Patient - MIO Laborbefund v1.0.0-update

MIO Laborbefund

Version 1.0.0-update - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **KBV_PR_MIO_LAB_Patient**

## Resource Profile: KBV_PR_MIO_LAB_Patient 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Patient | *Version*:1.0.0-update |
| Draft as of 2026-06-11 | *Computable Name*:KBV_PR_MIO_LAB_Patient |
| **Copyright/Legal**: Im folgenden Profil können Codes aus den Code-Systemen SNOMED CT®, LOINC, Ucum, ATC, ICD-10-GM, ICD-10-WHO, OPS, Alpha-ID/Alpha-ID-SE und ICF enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED CT® Clinical Terms® (SNOMED CT® CT®) which is used by permission of SNOMED CT® International. All rights reserved. SNOMED CT® CT®, was originally created by The College of American Pathologists. SNOMED CT® and SNOMED CT® CT are registered trademarks of SNOMED CT® International. Implementers of these artefacts must have the appropriate SNOMED CT® CT Affiliate license. This material contains content from LOINC (http://LOINC.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://LOINC.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED ‘AS IS.’ ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Dieses Material enthält Inhalte aus ATC. Die Erstellung erfolgte unter Verwendung der Datenträger der amtlichen Fassung der ATC-Klassifikation mit DDD des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICD-10-GM, ICD-10-WHO, OPS Alpha-ID ans Alpha-ID-SE. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICF. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Deutschen Instituts für Medizinische Dokumentation und Information (DIMDI). ICF-Kodes, -Begriffe und -Texte © Weltgesundheitsorganisation, übersetzt und herausgegeben durch das Deutsche Institut für Medizinische Dokumentation und Information von der International classification of functioning, disability and health - ICF, herausgegeben durch die Weltgesundheitsorganisation. | |

 
Dieses Profil bildet eine Person ab, die eine oder mehrere medizinische Leistungen in Anspruch nimmt. 

**Usages:**

* Use this Profile: [KBV_PR_MIO_LAB_Bundle](StructureDefinition-KBV-PR-MIO-LAB-Bundle.md)
* Refer to this Profile: [KBV_PR_MIO_LAB_BodyStructure](StructureDefinition-KBV-PR-MIO-LAB-BodyStructure.md), [KBV_PR_MIO_LAB_Composition](StructureDefinition-KBV-PR-MIO-LAB-Composition.md), [KBV_PR_MIO_LAB_Condition_Diagnosis](StructureDefinition-KBV-PR-MIO-LAB-Condition-Diagnosis.md), [KBV_PR_MIO_LAB_Device_Specimen_Subject](StructureDefinition-KBV-PR-MIO-LAB-Device-Specimen-Subject.md)... Show 8 more, [KBV_PR_MIO_LAB_DiagnosticReport](StructureDefinition-KBV-PR-MIO-LAB-DiagnosticReport.md), [KBV_PR_MIO_LAB_DocumentReference](StructureDefinition-KBV-PR-MIO-LAB-DocumentReference.md), [KBV_PR_MIO_LAB_Observation_Image_Attachment](StructureDefinition-KBV-PR-MIO-LAB-Observation-Image-Attachment.md), [KBV_PR_MIO_LAB_Observation_Laboratory_Study_Group](StructureDefinition-KBV-PR-MIO-LAB-Observation-Laboratory-Study-Group.md), [KBV_PR_MIO_LAB_Observation_Laboratory_Study](StructureDefinition-KBV-PR-MIO-LAB-Observation-Laboratory-Study.md), [KBV_PR_MIO_LAB_RelatedPerson](StructureDefinition-KBV-PR-MIO-LAB-RelatedPerson.md), [KBV_PR_MIO_LAB_ServiceRequest](StructureDefinition-KBV-PR-MIO-LAB-ServiceRequest.md) and [KBV_PR_MIO_LAB_Specimen](StructureDefinition-KBV-PR-MIO-LAB-Specimen.md)
* Examples for this Profile: [Patient/84e01fa5-6763-4a96-99f3-170cf9b317ff](Patient-84e01fa5-6763-4a96-99f3-170cf9b317ff.md) and [Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d](Patient-b65dfcca-c6ce-4dac-8742-8da00c192c7d.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/kbv.mio.laborbefund|current/StructureDefinition/StructureDefinition-KBV-PR-MIO-LAB-Patient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-KBV-PR-MIO-LAB-Patient.csv), [Excel](StructureDefinition-KBV-PR-MIO-LAB-Patient.xlsx), [Schematron](StructureDefinition-KBV-PR-MIO-LAB-Patient.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "KBV-PR-MIO-LAB-Patient",
  "url" : "https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Patient",
  "version" : "1.0.0-update",
  "name" : "KBV_PR_MIO_LAB_Patient",
  "title" : "KBV_PR_MIO_LAB_Patient",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-11",
  "publisher" : "mio42 GmbH",
  "contact" : [{
    "name" : "mio42 GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://mio.kbv.de"
    },
    {
      "system" : "email",
      "value" : "hello@mio42.de"
    }]
  }],
  "description" : "Dieses Profil bildet eine Person ab, die eine oder mehrere medizinische Leistungen in Anspruch nimmt.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "Im folgenden Profil können Codes aus den Code-Systemen SNOMED CT®, LOINC, Ucum, ATC, ICD-10-GM, ICD-10-WHO, OPS, Alpha-ID/Alpha-ID-SE und ICF enthalten sein, die dem folgenden Urheberrecht unterliegen: This material includes SNOMED CT® Clinical Terms® (SNOMED CT® CT®) which is used by permission of SNOMED CT® International. All rights reserved. SNOMED CT® CT®, was originally created by The College of American Pathologists. SNOMED CT® and SNOMED CT® CT are registered trademarks of SNOMED CT® International. Implementers of these artefacts must have the appropriate SNOMED CT® CT Affiliate license. This material contains content from LOINC (http://LOINC.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://LOINC.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc. This product includes all or a portion of the UCUM table, UCUM codes, and UCUM definitions or is derived from it, subject to a license from Regenstrief Institute, Inc. and The UCUM Organization. Your use of the UCUM table, UCUM codes, UCUM definitions also is subject to this license, a copy of which is available at http://unitsofmeasure.org. The current complete UCUM table, UCUM Specification are available for download at http://unitsofmeasure.org. The UCUM table and UCUM codes are copyright © 1995-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. THE UCUM TABLE (IN ALL FORMATS), UCUM DEFINITIONS, AND SPECIFICATION ARE PROVIDED 'AS IS.' ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Dieses Material enthält Inhalte aus ATC. Die Erstellung erfolgte unter Verwendung der Datenträger der amtlichen Fassung der ATC-Klassifikation mit DDD des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICD-10-GM, ICD-10-WHO, OPS Alpha-ID ans Alpha-ID-SE. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Bundesinstituts für Arzneimittel und Medizinprodukte (BfArM). Dieses Material enthält Inhalte aus ICF. Die Erstellung erfolgt unter Verwendung der maschinenlesbaren Fassung des Deutschen Instituts für Medizinische Dokumentation und Information (DIMDI). ICF-Kodes, -Begriffe und -Texte © Weltgesundheitsorganisation, übersetzt und herausgegeben durch das Deutsche Institut für Medizinische Dokumentation und Information von der International classification of functioning, disability and health - ICF, herausgegeben durch die Weltgesundheitsorganisation.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient",
      "path" : "Patient",
      "constraint" : [{
        "key" : "pat-de-1",
        "severity" : "error",
        "human" : "Die amtliche Differenzierung der Geschlechtsangabe 'other' darf nur gefüllt sein, wenn das Geschlecht 'other' angegeben ist.",
        "expression" : "gender.exists() and gender='other' implies gender.extension('http://fhir.de/StructureDefinition/gender-amtlich-de').exists()",
        "source" : "https://fhir.kbv.de/StructureDefinition/KBV_PR_MIO_LAB_Patient"
      }]
    },
    {
      "id" : "Patient.meta",
      "path" : "Patient.meta",
      "mustSupport" : true
    },
    {
      "id" : "Patient.meta.id",
      "path" : "Patient.meta.id",
      "max" : "0"
    },
    {
      "id" : "Patient.meta.versionId",
      "path" : "Patient.meta.versionId",
      "mustSupport" : true
    },
    {
      "id" : "Patient.meta.lastUpdated",
      "path" : "Patient.meta.lastUpdated",
      "mustSupport" : true
    },
    {
      "id" : "Patient.meta.source",
      "path" : "Patient.meta.source",
      "max" : "0"
    },
    {
      "id" : "Patient.implicitRules",
      "path" : "Patient.implicitRules",
      "max" : "0"
    },
    {
      "id" : "Patient.language",
      "path" : "Patient.language",
      "max" : "0"
    },
    {
      "id" : "Patient.text.status",
      "path" : "Patient.text.status",
      "patternCode" : "extensions"
    },
    {
      "id" : "Patient.contained",
      "path" : "Patient.contained",
      "max" : "0"
    },
    {
      "id" : "Patient.extension",
      "path" : "Patient.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "closed"
      },
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use",
      "path" : "Patient.extension",
      "sliceName" : "sex-for-clinical-use",
      "definition" : "Die Angabe des klinisch relevanten Geschlechts ist für die aktuelle klinische Entscheidungsfindung gedacht. Sie weist darauf hin, auf welcher Referenzpopulation bei geschlechtsspezifischen Richtgrenzen eine Messergebnis-Bewertung basieren sollte.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/patient-sexParameterForClinicalUse|5.3.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension",
      "path" : "Patient.extension.extension",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value",
      "path" : "Patient.extension.extension",
      "sliceName" : "value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x]",
      "path" : "Patient.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding",
      "path" : "Patient.extension.extension.value[x].coding",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding.system",
      "path" : "Patient.extension.extension.value[x].coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding.version",
      "path" : "Patient.extension.extension.value[x].coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding.code",
      "path" : "Patient.extension.extension.value[x].coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding.display",
      "path" : "Patient.extension.extension.value[x].coding.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].coding.userSelected",
      "path" : "Patient.extension.extension.value[x].coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:value.value[x].text",
      "path" : "Patient.extension.extension.value[x].text",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:period",
      "path" : "Patient.extension.extension",
      "sliceName" : "period",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:period.value[x]",
      "path" : "Patient.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:period.value[x].start",
      "path" : "Patient.extension.extension.value[x].start",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:period.value[x].end",
      "path" : "Patient.extension.extension.value[x].end",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:comment",
      "path" : "Patient.extension.extension",
      "sliceName" : "comment",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:comment.value[x]",
      "path" : "Patient.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:supportingInfo",
      "path" : "Patient.extension.extension",
      "sliceName" : "supportingInfo",
      "max" : "0"
    },
    {
      "id" : "Patient.extension:sex-for-clinical-use.extension:intendedClinicalUse",
      "path" : "Patient.extension.extension",
      "sliceName" : "intendedClinicalUse",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "type"
        }],
        "rules" : "open"
      },
      "definition" : "In diesem Element wird der Identifier (Identifikator) für die Person eingetragen. Der Identifikator kann aus diversen Quellen stammen.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid",
      "path" : "Patient.identifier",
      "sliceName" : "pid",
      "definition" : "Abbildung einer organisationsspezifischen Patienten-ID. Die PID kann beispielsweise als Identifikator verwendet werden, wenn eine einsendende Praxis den Laborbefund in pseudonymisierter Form übermittelt bekommen möchte. Nach welchen Regeln und mit welchem Identifier ein pseudonymisierter Laborbefund übermittelt wird, wäre in solcher Konstellation Gegenstand einer Einzelabstimmung zwischen Praxis und Labor.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-pid"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:pid.type.coding",
      "path" : "Patient.identifier.type.coding",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.type.coding.version",
      "path" : "Patient.identifier.type.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.type.coding.display",
      "path" : "Patient.identifier.type.coding.display",
      "min" : 1,
      "patternString" : "Krankenaktennummer",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.type.coding.userSelected",
      "path" : "Patient.identifier.type.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:pid.type.text",
      "path" : "Patient.identifier.type.text",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:pid.system",
      "path" : "Patient.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.value",
      "path" : "Patient.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:pid.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:pid.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertenId",
      "path" : "Patient.identifier",
      "sliceName" : "versichertenId",
      "definition" : "Hier wird der unveränderliche Teil der einheitlichen Krankenversicherungsnummer der GKV gemäß § 290 SGB V angegeben. Die 10-stellige Zeichenfolge beginnt mit einem zufällig vergebene Großbuchstaben, darauf folgen 8 zufällige Ziffern.  Das 10.Zeichen ist eine Prüfziffer.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-kvid-10"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertenId.type",
      "path" : "Patient.identifier.type",
      "min" : 1
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding",
      "path" : "Patient.identifier.type.coding",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding.version",
      "path" : "Patient.identifier.type.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding.display",
      "path" : "Patient.identifier.type.coding.display",
      "min" : 1,
      "patternString" : "Krankenversichertennummer",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.type.coding.userSelected",
      "path" : "Patient.identifier.type.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertenId.type.text",
      "path" : "Patient.identifier.type.text",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertenId.system",
      "path" : "Patient.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.value",
      "path" : "Patient.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertenId.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertenId.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv",
      "path" : "Patient.identifier",
      "sliceName" : "versichertennummer_pkv",
      "definition" : "Hier wird der Identifikator für eine Privatversichertennummer angegeben.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-pkv"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type",
      "path" : "Patient.identifier.type",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_Base_identifier_type",
          "code" : "pkv-nr"
        }]
      }
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding",
      "path" : "Patient.identifier.type.coding",
      "min" : 2,
      "max" : "2",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding.version",
      "path" : "Patient.identifier.type.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding.display",
      "path" : "Patient.identifier.type.coding.display",
      "min" : 1,
      "patternString" : "Private Krankenversicherung",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.coding.userSelected",
      "path" : "Patient.identifier.type.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.type.text",
      "path" : "Patient.identifier.type.text",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.system",
      "path" : "Patient.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.value",
      "path" : "Patient.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.assigner.reference",
      "path" : "Patient.identifier.assigner.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.assigner.type",
      "path" : "Patient.identifier.assigner.type",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_pkv.assigner.identifier",
      "path" : "Patient.identifier.assigner.identifier",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:reisepassnummer",
      "path" : "Patient.identifier",
      "sliceName" : "reisepassnummer",
      "definition" : "Hier wird die Reisepassnummer angegeben.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Identifier_Reisepassnummer"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding",
      "path" : "Patient.identifier.type.coding",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding.version",
      "path" : "Patient.identifier.type.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding.display",
      "path" : "Patient.identifier.type.coding.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.coding.userSelected",
      "path" : "Patient.identifier.type.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:reisepassnummer.type.text",
      "path" : "Patient.identifier.type.text",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:reisepassnummer.system",
      "path" : "Patient.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.value",
      "path" : "Patient.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:reisepassnummer.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:reisepassnummer.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk",
      "path" : "Patient.identifier",
      "sliceName" : "versichertennummer_kvk",
      "definition" : "Hier wird die Versichertennummer der Krankenversichertenkarte (KVK) angegeben.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Identifier_KVK"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding",
      "path" : "Patient.identifier.type.coding",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding.version",
      "path" : "Patient.identifier.type.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding.display",
      "path" : "Patient.identifier.type.coding.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.coding.userSelected",
      "path" : "Patient.identifier.type.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.type.text",
      "path" : "Patient.identifier.type.text",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.system",
      "path" : "Patient.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.value",
      "path" : "Patient.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:versichertennummer_kvk.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.active",
      "path" : "Patient.active",
      "max" : "0"
    },
    {
      "id" : "Patient.name",
      "path" : "Patient.name",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "use"
        }],
        "rules" : "closed"
      },
      "definition" : "Dieses Element beschreibt den vollständigen Namen der behandelten Person.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name",
      "path" : "Patient.name",
      "sliceName" : "name",
      "definition" : "Dieses Element beschreibt diverse Namensbestandteile der behandelten Person.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "HumanName",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Datatype_Name"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.text",
      "path" : "Patient.name.text",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family",
      "path" : "Patient.name.family",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension",
      "path" : "Patient.name.family.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "closed"
      },
      "min" : 1,
      "max" : "3",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:namenszusatz",
      "path" : "Patient.name.family.extension",
      "sliceName" : "namenszusatz",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:namenszusatz.value[x]",
      "path" : "Patient.name.family.extension.value[x]",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:nachname",
      "path" : "Patient.name.family.extension",
      "sliceName" : "nachname",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:nachname.value[x]",
      "path" : "Patient.name.family.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:vorsatzwort",
      "path" : "Patient.name.family.extension",
      "sliceName" : "vorsatzwort",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.family.extension:vorsatzwort.value[x]",
      "path" : "Patient.name.family.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.given",
      "path" : "Patient.name.given",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.prefix",
      "path" : "Patient.name.prefix",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.prefix.extension:prefix-qualifier",
      "path" : "Patient.name.prefix.extension",
      "sliceName" : "prefix-qualifier",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.prefix.extension:prefix-qualifier.value[x]",
      "path" : "Patient.name.prefix.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.prefix.extension:prefix-qualifier.value[x]:valueCode",
      "path" : "Patient.name.prefix.extension.value[x]",
      "sliceName" : "valueCode",
      "type" : [{
        "code" : "code"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:name.suffix",
      "path" : "Patient.name.suffix",
      "max" : "0"
    },
    {
      "id" : "Patient.name:name.period",
      "path" : "Patient.name.period",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung",
      "path" : "Patient.name",
      "sliceName" : "Pseudonymisierung",
      "definition" : "Dieses Element wird verwendet, falls der Laborgesamtbefund Pseudonymisiert ist.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:Pseudonymisierung.id",
      "path" : "Patient.name.id",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.extension",
      "path" : "Patient.name.extension",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:Pseudonymisierung.extension:data-absent-reason",
      "path" : "Patient.name.extension",
      "sliceName" : "data-absent-reason",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/data-absent-reason|5.3.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:Pseudonymisierung.extension:data-absent-reason.value[x]",
      "path" : "Patient.name.extension.value[x]",
      "fixedCode" : "unknown",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name:Pseudonymisierung.use",
      "path" : "Patient.name.use",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.text",
      "path" : "Patient.name.text",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.family",
      "path" : "Patient.name.family",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.given",
      "path" : "Patient.name.given",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.prefix",
      "path" : "Patient.name.prefix",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.suffix",
      "path" : "Patient.name.suffix",
      "max" : "0"
    },
    {
      "id" : "Patient.name:Pseudonymisierung.period",
      "path" : "Patient.name.period",
      "max" : "0"
    },
    {
      "id" : "Patient.telecom",
      "path" : "Patient.telecom",
      "definition" : "Dieses Element beschreibt die vorhandenen Kontaktmöglichkeiten.",
      "type" : [{
        "code" : "ContactPoint",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Datatype_Contactpoint"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.telecom.system",
      "path" : "Patient.telecom.system",
      "definition" : "Hier wird die Art des Kontaktes definiert, z. B. Telefon (phone), E-Mail, Fax.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.telecom.value",
      "path" : "Patient.telecom.value",
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender",
      "path" : "Patient.gender",
      "definition" : "Hier wird die Geschlechtsdefinition nach den Versichertenstammdaten (VSD) angegeben.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension",
      "path" : "Patient.gender.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "closed"
      },
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich",
      "path" : "Patient.gender.extension",
      "sliceName" : "other-amtlich",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.de/StructureDefinition/gender-amtlich-de"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x]",
      "path" : "Patient.gender.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x].system",
      "path" : "Patient.gender.extension.value[x].system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x].version",
      "path" : "Patient.gender.extension.value[x].version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x].code",
      "path" : "Patient.gender.extension.value[x].code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x].display",
      "path" : "Patient.gender.extension.value[x].display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender.extension:other-amtlich.value[x].userSelected",
      "path" : "Patient.gender.extension.value[x].userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.birthDate",
      "path" : "Patient.birthDate",
      "definition" : "Hier wird das Geburtsdatum der behandelten Person angegeben. Ist dieses nicht bekannt kann die Extension 'data-absent-reason' verwendet werden, um das Nichtvorhandensein zu dokumentieren.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.birthDate.extension",
      "path" : "Patient.birthDate.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "closed"
      },
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.birthDate.extension:data-absent-reason",
      "path" : "Patient.birthDate.extension",
      "sliceName" : "data-absent-reason",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/data-absent-reason|5.3.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.birthDate.extension:data-absent-reason.value[x]",
      "path" : "Patient.birthDate.extension.value[x]",
      "fixedCode" : "unknown",
      "mustSupport" : true
    },
    {
      "id" : "Patient.deceased[x]",
      "path" : "Patient.deceased[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "definition" : "Zeigt an, ob bzw. wann die Person verstorben ist.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.deceased[x]:deceasedBoolean",
      "path" : "Patient.deceased[x]",
      "sliceName" : "deceasedBoolean",
      "definition" : "Zeigt an, ob die Person verstorben ist.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.deceased[x]:deceasedDateTime",
      "path" : "Patient.deceased[x]",
      "sliceName" : "deceasedDateTime",
      "definition" : "Zeigt an, zu welchem Zeitpunkt die Person verstorben ist.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.address",
      "path" : "Patient.address",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "type"
        }],
        "rules" : "closed"
      },
      "definition" : "Hier können Angaben zur Anschrift der behandelten Person gemacht werden.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address.use",
      "path" : "Patient.address.use",
      "max" : "0"
    },
    {
      "id" : "Patient.address.state",
      "path" : "Patient.address.state",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Strassenanschrift",
      "path" : "Patient.address",
      "sliceName" : "Strassenanschrift",
      "definition" : "Hier werden Angaben zur Straßenanschrift gemacht.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Address",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Datatype_Street_Address"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.extension",
      "path" : "Patient.address.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "description" : "Extensions are always sliced by (at least) url",
        "rules" : "closed"
      },
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.extension:Stadtteil",
      "path" : "Patient.address.extension",
      "sliceName" : "Stadtteil",
      "definition" : "In diesem Element kann der Stadt- oder Ortsteil angegeben werden, z. B. wenn der Ort ein Stadtstaat ist.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.extension:Stadtteil.value[x]",
      "path" : "Patient.address.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.use",
      "path" : "Patient.address.use",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Strassenanschrift.type",
      "path" : "Patient.address.type",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.text",
      "path" : "Patient.address.text",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Strassenanschrift.line",
      "path" : "Patient.address.line",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension",
      "path" : "Patient.address.line.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "closed"
      },
      "max" : "3",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Strasse",
      "path" : "Patient.address.line.extension",
      "sliceName" : "Strasse",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Strasse.value[x]",
      "path" : "Patient.address.line.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Hausnummer",
      "path" : "Patient.address.line.extension",
      "sliceName" : "Hausnummer",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Hausnummer.value[x]",
      "path" : "Patient.address.line.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Adresszusatz",
      "path" : "Patient.address.line.extension",
      "sliceName" : "Adresszusatz",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.line.extension:Adresszusatz.value[x]",
      "path" : "Patient.address.line.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.city",
      "path" : "Patient.address.city",
      "definition" : "In dieses Feld kann der Ort eingetragen werden.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.state",
      "path" : "Patient.address.state",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Strassenanschrift.postalCode",
      "path" : "Patient.address.postalCode",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.country",
      "path" : "Patient.address.country",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Strassenanschrift.period",
      "path" : "Patient.address.period",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Postfach",
      "path" : "Patient.address",
      "sliceName" : "Postfach",
      "definition" : "Hier werden Angaben zu einem Postfach gemacht.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Address",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Datatype_Post_Office_Box"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.extension",
      "path" : "Patient.address.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "description" : "Extensions are always sliced by (at least) url",
        "rules" : "closed"
      },
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.extension:Stadtteil",
      "path" : "Patient.address.extension",
      "sliceName" : "Stadtteil",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.extension:Stadtteil.value[x]",
      "path" : "Patient.address.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.use",
      "path" : "Patient.address.use",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Postfach.type",
      "path" : "Patient.address.type",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.text",
      "path" : "Patient.address.text",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Postfach.line",
      "path" : "Patient.address.line",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.line.extension",
      "path" : "Patient.address.line.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "closed"
      },
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.line.extension:Postfach",
      "path" : "Patient.address.line.extension",
      "sliceName" : "Postfach",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.line.extension:Postfach.value[x]",
      "path" : "Patient.address.line.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.city",
      "path" : "Patient.address.city",
      "definition" : "In dieses Feld kann der Ort eingetragen werden.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.state",
      "path" : "Patient.address.state",
      "max" : "0"
    },
    {
      "id" : "Patient.address:Postfach.postalCode",
      "path" : "Patient.address.postalCode",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.country",
      "path" : "Patient.address.country",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address:Postfach.period",
      "path" : "Patient.address.period",
      "max" : "0"
    },
    {
      "id" : "Patient.maritalStatus",
      "path" : "Patient.maritalStatus",
      "short" : "Personenstand",
      "definition" : "Hier wird der Personenstand (Familienstand) der behandelten Person angegeben.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding",
      "path" : "Patient.maritalStatus.coding",
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding.system",
      "path" : "Patient.maritalStatus.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding.version",
      "path" : "Patient.maritalStatus.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding.code",
      "path" : "Patient.maritalStatus.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding.display",
      "path" : "Patient.maritalStatus.coding.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus.coding.userSelected",
      "path" : "Patient.maritalStatus.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.multipleBirth[x]",
      "path" : "Patient.multipleBirth[x]",
      "max" : "0"
    },
    {
      "id" : "Patient.photo",
      "path" : "Patient.photo",
      "max" : "0"
    },
    {
      "id" : "Patient.contact",
      "path" : "Patient.contact",
      "max" : "0"
    },
    {
      "id" : "Patient.contact.address.country",
      "path" : "Patient.contact.address.country",
      "short" : "Staat",
      "definition" : "Angabe des Staates als Länderkennzeichen nach DEUEV Anlage 8.",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://fhir.kbv.de/ValueSet/KBV_VS_Base_Deuev_Anlage_8"
      }
    },
    {
      "id" : "Patient.communication",
      "path" : "Patient.communication",
      "definition" : "Sprachen, die zur Kommunikation mit der behandelten Person über medizinische Themen verwendet werden können",
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language",
      "path" : "Patient.communication.language",
      "short" : "Bevorzugte Sprache",
      "definition" : "Hier werden Sprachen angegeben, die zur Kommunikation mit der behandelten Person über medizinische Themen verwendet werden können.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.kbv.de/ValueSet/KBV_VS_Base_CommonLanguages"
      }
    },
    {
      "id" : "Patient.communication.language.coding",
      "path" : "Patient.communication.language.coding",
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language.coding.system",
      "path" : "Patient.communication.language.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language.coding.version",
      "path" : "Patient.communication.language.coding.version",
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language.coding.code",
      "path" : "Patient.communication.language.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language.coding.display",
      "path" : "Patient.communication.language.coding.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.communication.language.coding.userSelected",
      "path" : "Patient.communication.language.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Patient.communication.language.text",
      "path" : "Patient.communication.language.text",
      "max" : "0"
    },
    {
      "id" : "Patient.communication.preferred",
      "path" : "Patient.communication.preferred",
      "max" : "0"
    },
    {
      "id" : "Patient.generalPractitioner",
      "path" : "Patient.generalPractitioner",
      "max" : "0"
    },
    {
      "id" : "Patient.managingOrganization",
      "path" : "Patient.managingOrganization",
      "max" : "0"
    },
    {
      "id" : "Patient.link",
      "path" : "Patient.link",
      "max" : "0"
    }]
  }
}

```
